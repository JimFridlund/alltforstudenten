<?php
header("Location: /app/login.php", true, 302);
exit;
?>