<?php
$this_user = (class_exists('Auth') && Auth::user()) ? Auth::user() : null;

if (!isset($page_title)) $page_title = "Viddra";
$logged_in = class_exists('Auth') ? Auth::isLoggedIn() : false;
?>
<!DOCTYPE html>
<html lang="en-GB">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title><?php echo htmlspecialchars($page_title, ENT_QUOTES, 'UTF-8'); ?></title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,700&family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/assets/css/app.css?v=11" />
  <link rel="stylesheet" href="/assets/onboarding.css">
</head>
<body>

<header class="app-header">
  <div class="container header-inner">
    <div class="brand">
      <span class="brand-mark">V</span>
      <span class="brand-name">Viddra</span>
    </div>
    <nav class="nav">
      <a href="/app/dashboard.php">Home</a>
      <a href="/app/transactions.php">Transactions</a>
      <a href="/app/budget.php">Budget</a>
      <a href="/app/forecast.php">Forecast</a>
      <?php if ($logged_in): ?>
        <a href="/app/household.php">Household</a>
        <div class="dd">
          <a class="dd-toggle" href="/app/profile.php" aria-haspopup="true" aria-expanded="false">Account <span class="dd-caret">▾</span></a>
          <div class="dd-menu" role="menu">
            <a role="menuitem" href="/app/profile.php">Profile</a>
            <a role="menuitem" href="/app/billing.php">Billing</a>
            <a role="menuitem" href="/app/logout.php">Logout</a>
          </div>
        </div>
      <?php else: ?>
        <a href="/app/login.php">Sign in</a>
      <?php endif; ?>
    </nav>
  </div>
</header>


<?php if ($this_user && !($this_user['email_verified_at'] ?? null)): ?>
  <div class="email-banner">
    <div class="container">
      <strong>Verify your email</strong>
      <span class="muted">Protect invites + billing.</span>
      <a href="/app/verify_email.php">Verify now</a>
    </div>
  </div>
<?php endif; ?>
<main class="app-main">
