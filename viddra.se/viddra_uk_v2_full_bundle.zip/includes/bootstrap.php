<?php
// Viddra bootstrap (Step 11)
session_start();

require_once __DIR__ . '/config.php';

spl_autoload_register(function($class){
  $base = __DIR__ . '/../core/';
  $path = $base . $class . '.php';
  if (file_exists($path)) require_once $path;
});

if (!defined('VIDDRA_SCENARIO_KEY')) define('VIDDRA_SCENARIO_KEY', 'viddra_scenario');

function viddra_scenario_store(){
  $mode = defined('VIDDRA_SCENARIO_STORE') ? VIDDRA_SCENARIO_STORE : 'session';
  if ($mode === 'db') {
    $uid = Auth::userId();
    if ($uid <= 0) return new SessionScenarioStore(); // fallback
    // Ensure household exists and is set as current
    $hid = Household::currentId();
    if ($hid <= 0) {
      $hid = Household::ensureDefaultForUser($uid);
      Household::setCurrentId($hid);
    }
    return new DatabaseScenarioStore(Database::pdo(), $hid, $uid);
  }
  return new SessionScenarioStore();
}

 // CSRF helpers (v1)
function viddra_csrf_token(){
  if (!isset($_SESSION['viddra_csrf'])) {
    $_SESSION['viddra_csrf'] = bin2hex(random_bytes(16));
  }
  return $_SESSION['viddra_csrf'];
}
function viddra_csrf_check($token){
  return isset($_SESSION['viddra_csrf']) && hash_equals($_SESSION['viddra_csrf'], (string)$token);
}
?>

require_once __DIR__ . '/../core/Financials.php';

require_once __DIR__ . '/../core/Category.php';

require_once __DIR__ . '/../core/Transaction.php';

require_once __DIR__ . '/../core/Rollup.php';

require_once __DIR__ . '/../core/Budget.php';

require_once __DIR__ . '/../core/Forecast.php';
