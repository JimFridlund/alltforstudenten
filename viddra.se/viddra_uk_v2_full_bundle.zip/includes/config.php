<?php
/**
 * Viddra config (Step 11)
 */

// === Database (MySQL) ===
define('VIDDRA_DB_HOST', 'localhost');
define('VIDDRA_DB_NAME', 'viddra_db');
define('VIDDRA_DB_USER', 'viddra_user');
define('VIDDRA_DB_PASS', 'CHANGE_ME');
define('VIDDRA_DB_CHARSET', 'utf8mb4');

// === Scenario store mode ===
define('VIDDRA_SCENARIO_STORE', 'db'); // 'db' (recommended) or 'session'

// === Security ===
// Change this to a long random string in production.
define('VIDDRA_APP_SECRET', 'CHANGE_ME_TO_A_LONG_RANDOM_STRING');
?>

// === Email (invites) ===
// Option A (default): PHP mail() via hosting
define('VIDDRA_MAIL_DRIVER', 'mail'); // 'mail' or 'smtp'

// From address shown to recipient
define('VIDDRA_MAIL_FROM', 'no-reply@viddra.se');
define('VIDDRA_MAIL_FROM_NAME', 'Viddra');

// Base URL used in invite links (IMPORTANT in production)
define('VIDDRA_BASE_URL', 'https://viddra.se');

// Option B: SMTP (if you later implement PHPMailer or similar)
// define('VIDDRA_SMTP_HOST', 'smtp.example.com');
// define('VIDDRA_SMTP_PORT', 587);
// define('VIDDRA_SMTP_USER', 'user');
// define('VIDDRA_SMTP_PASS', 'pass');
// define('VIDDRA_SMTP_SECURE', 'tls');

// === Billing (Step 17) ===
// 'manual' = internal activate/deactivate (no Stripe yet)
// 'stripe' = placeholder for next step integration
define('VIDDRA_BILLING_MODE', 'manual');

// Gate app pages behind active subscription?
// Recommended: keep false until Stripe is integrated.
define('VIDDRA_REQUIRE_SUBSCRIPTION', false);

// === Stripe (Step 18) ===
define('VIDDRA_BILLING_MODE', 'stripe'); // 'manual' or 'stripe'

// Stripe keys (set in hosting env or edit here)
// Secret key: sk_live_... or sk_test_...
define('VIDDRA_STRIPE_SECRET_KEY', 'CHANGE_ME');
// Webhook signing secret: whsec_...
define('VIDDRA_STRIPE_WEBHOOK_SECRET', 'CHANGE_ME');

// Stripe Price ID for Viddra Plus (£11/mo) created in Stripe dashboard
define('VIDDRA_STRIPE_PRICE_ID_PLUS_MONTHLY', 'price_CHANGE_ME');

// Where Stripe should redirect after checkout
define('VIDDRA_STRIPE_SUCCESS_URL', VIDDRA_BASE_URL . '/app/billing.php?stripe=success');
define('VIDDRA_STRIPE_CANCEL_URL',  VIDDRA_BASE_URL . '/app/billing.php?stripe=cancel');

// Stripe Customer Portal return URL
define('VIDDRA_STRIPE_PORTAL_RETURN_URL', VIDDRA_BASE_URL . '/app/billing.php?portal=return');

// === Admin (Step 20) ===
// Comma-separated emails allowed to view webhook logs
define('VIDDRA_ADMIN_EMAILS', 'jim@example.com');

// === Email verification (Step 23) ===
define('VIDDRA_REQUIRE_EMAIL_VERIFICATION', false); // turn true when ready
define('VIDDRA_EMAIL_VERIFY_COOLDOWN_SECONDS', 120);

// Invites (Step 24)
define('VIDDRA_INVITE_REQUIRES_VERIFIED_EMAIL', true);

// Invites TTL (Step 25)
define('VIDDRA_INVITE_TTL_HOURS', 168); // 7 days

// Invite utilities (Step 26)
define('VIDDRA_SHOW_INVITE_COPY_LINK', true); // show "copy link" for pending invites (admin/dev convenience)
