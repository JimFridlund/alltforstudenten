<?php
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
Auth::requireVerifiedEmail();

$hid = Household::currentId();
Category::seedDefaults($hid);

$ym = $_GET['ym'] ?? date('Y-m');
list($ym, $start, $end) = Rollup::monthRange($ym);

$data = Forecast::projectMonth($hid, $ym);

function gbp($n){
  return "£" . number_format((float)$n, 2, '.', ',');
}

$page_title = "Forecast — Viddra";
include __DIR__ . '/../includes/header.php';
?>

<section class="section">
  <div class="container">
    <div class="card big">
      <h1>Forecast</h1>
      <p class="muted">Based on what you’ve logged so far this month.</p>

      <div class="snap-grid" style="margin-top:14px">
        <div class="snap-card"><h3>Days logged</h3><strong><?php echo (int)$data['days_elapsed']; ?> / <?php echo (int)$data['days_total']; ?></strong></div>
        <div class="snap-card"><h3>Projected total</h3><strong><?php echo gbp($data['totals']['projected']); ?></strong></div>
        <div class="snap-card"><h3>Projected vs Budget</h3><strong><?php echo gbp($data['totals']['diff_projected_vs_budget']); ?></strong></div>
      </div>

      <div class="form-actions" style="margin-top:12px">
        <a class="btn" href="/app/transactions.php">Add transactions</a>
        <a class="btn" href="/app/budget.php?ym=<?php echo urlencode($ym); ?>">Budget vs Actual</a>
        <a class="btn" href="/app/monthly.php?ym=<?php echo urlencode($ym); ?>">Monthly rollup</a>
      </div>

      <hr style="margin:18px 0">

      <h2 style="margin-top:0">Projected by category</h2>

      <table style="width:100%;margin-top:10px">
        <tr>
          <th align="left">Category</th>
          <th align="left">Type</th>
          <th align="right">Budget</th>
          <th align="right">Actual to date</th>
          <th align="right">Projected</th>
          <th align="right">Proj - Budget</th>
        </tr>

        <?php foreach ($data['rows'] as $r): ?>
          <tr>
            <td><?php echo htmlspecialchars($r['category_name'], ENT_QUOTES, 'UTF-8'); ?></td>
            <td><?php echo htmlspecialchars($r['category_type'], ENT_QUOTES, 'UTF-8'); ?></td>
            <td align="right"><?php echo gbp($r['budget']); ?></td>
            <td align="right" style="font-weight:900"><?php echo gbp($r['actual_to_date']); ?></td>
            <td align="right" style="font-weight:900"><?php echo gbp($r['projected']); ?></td>
            <td align="right" style="font-weight:900;opacity:.85"><?php echo gbp($r['diff_projected_vs_budget']); ?></td>
          </tr>
        <?php endforeach; ?>

        <tr>
          <td colspan="2" style="padding-top:12px"><strong>Total</strong></td>
          <td align="right" style="padding-top:12px"><strong><?php echo gbp($data['totals']['budget']); ?></strong></td>
          <td align="right" style="padding-top:12px"><strong><?php echo gbp($data['totals']['actual_to_date']); ?></strong></td>
          <td align="right" style="padding-top:12px"><strong><?php echo gbp($data['totals']['projected']); ?></strong></td>
          <td align="right" style="padding-top:12px"><strong><?php echo gbp($data['totals']['diff_projected_vs_budget']); ?></strong></td>
        </tr>
      </table>
    </div>
  </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
