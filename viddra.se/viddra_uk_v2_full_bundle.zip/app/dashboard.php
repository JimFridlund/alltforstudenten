<?php
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();

$page_title = "Home — Viddra";
$uid = Auth::userId();
$hid = Household::currentId();
if ($hid <= 0) { $hid = Household::ensureDefaultForUser($uid); Household::setCurrentId($hid); }

$pdo = Database::pdo();
$ym = date('Y-m');
$monthStart = $ym . '-01';
$monthEnd = date('Y-m-t');

$stmt = $pdo->prepare("SELECT * FROM viddra_household_financials WHERE household_id=? LIMIT 1");
$stmt->execute([$hid]);
$fin = $stmt->fetch();

$income = $fin ? (float)($fin['income_total'] ?? 0) : 0.0;
$fixed  = $fin ? (float)($fin['fixed_total'] ?? 0)  : 0.0;
$goal   = $fin ? (float)($fin['goal_total'] ?? 0)   : 0.0;

$stmt = $pdo->prepare("SELECT COALESCE(SUM(amount),0) AS s FROM viddra_transactions WHERE household_id=? AND tx_date BETWEEN ? AND ?");
$stmt->execute([$hid, $monthStart, $monthEnd]);
$actual = (float)$stmt->fetch()['s'];

$spent = abs(min(0,$actual));
$net   = $income + $actual;

$locked = abs($fixed) + abs($goal);
$available = max(0, $income - $locked - $spent);

$day = (int)date('j');
$daysInMonth = (int)date('t');
$runrateSpent = ($day > 0) ? ($spent / max(1,$day) * $daysInMonth) : $spent;
$projectedEnd = ($income - $locked - $runrateSpent);

$alerts = [];
$stmt = $pdo->prepare("
  SELECT c.name,
         ABS(COALESCE(SUM(t.amount),0)) AS spent,
         ABS(COALESCE(b.budget_amount,0)) AS budget
  FROM viddra_categories c
  LEFT JOIN viddra_transactions t
    ON t.category_id=c.id AND t.household_id=c.household_id AND t.tx_date BETWEEN ? AND ?
  LEFT JOIN viddra_budgets b
    ON b.category_id=c.id AND b.household_id=c.household_id AND b.ym=?
  WHERE c.household_id=?
  GROUP BY c.id
  HAVING budget > 0 AND spent > budget*1.05
  ORDER BY (spent-budget) DESC
  LIMIT 3
");
$stmt->execute([$monthStart, $monthEnd, $ym, $hid]);
foreach ($stmt->fetchAll() as $r){
  $over = (float)$r['spent'] - (float)$r['budget'];
  $alerts[] = "You're £" . number_format($over,0) . " over pace in " . $r['name'] . ".";
}

include __DIR__ . '/../includes/header.php';
?>
<section class="section">
  <div class="container">
    <div class="row between center">
      <div>
        <span class="pill">This month • <?php echo htmlspecialchars(date('F Y'), ENT_QUOTES, 'UTF-8'); ?></span>
        <h1>Money clarity, not banking.</h1>
        <p class="lead">A calm overview of what's locked, what's left, and how you're trending.</p>
      </div>
      <div class="row center">
        <a class="btn" href="/app/transactions.php">Add spending</a>
        <a class="btn primary" href="/app/onboarding.php"><?php echo $fin ? "Update setup" : "Finish setup"; ?></a>
      </div>
    </div>

    <div class="grid three" style="margin-top:14px">
      <div class="card small">
        <div class="kpi">
          <div class="label">Available to spend</div>
          <div class="value">£<?php echo number_format($available,0); ?></div>
          <div class="tiny">After fixed + goals + spending so far.</div>
        </div>
      </div>
      <div class="card small">
        <div class="kpi">
          <div class="label">Locked (fixed + goals)</div>
          <div class="value">£<?php echo number_format($locked,0); ?></div>
          <div class="tiny">Bills and savings you chose to protect.</div>
        </div>
      </div>
      <div class="card small">
        <div class="kpi">
          <div class="label">End of month projection</div>
          <div class="value">£<?php echo number_format($projectedEnd,0); ?></div>
          <div class="tiny">Based on your current pace.</div>
        </div>
      </div>
    </div>

    <div class="grid two" style="margin-top:14px">
      <div class="card">
        <h2>What happened so far</h2>
        <div class="grid three" style="margin-top:12px">
          <div class="kpi">
            <div class="label">Income</div>
            <div class="value">£<?php echo number_format($income,0); ?></div>
          </div>
          <div class="kpi">
            <div class="label">Spent</div>
            <div class="value">£<?php echo number_format($spent,0); ?></div>
          </div>
          <div class="kpi">
            <div class="label">Net</div>
            <div class="value">£<?php echo number_format($net,0); ?></div>
          </div>
        </div>
        <p class="tiny" style="margin-top:10px">Tip: keep expenses as negative numbers (e.g. -12.50) for clean maths.</p>
        <div class="row" style="margin-top:10px">
          <a class="btn" href="/app/budget.php">Review budget</a>
          <a class="btn" href="/app/forecast.php">View forecast</a>
        </div>
      </div>

      <div class="card">
        <h2>Alerts</h2>
        <p class="lead" style="margin-top:6px">Small nudges that prevent surprises.</p>

        <?php if (count($alerts) === 0): ?>
          <div class="card small" style="box-shadow:none">
            <div class="tiny">No overspend alerts yet. You're on track.</div>
          </div>
        <?php else: ?>
          <ul class="tiny" style="margin:0;padding-left:18px">
            <?php foreach ($alerts as $a): ?>
              <li style="margin:8px 0"><?php echo htmlspecialchars($a, ENT_QUOTES, 'UTF-8'); ?></li>
            <?php endforeach; ?>
          </ul>
        <?php endif; ?>

        <div class="row" style="margin-top:12px">
          <a class="btn primary" href="/app/decisions.php">Try a decision</a>
          <a class="btn" href="/app/transactions.php">See spending</a>
        </div>
      </div>
    </div>
  </div>
</section>
<?php include __DIR__ . '/../includes/footer.php'; ?>
