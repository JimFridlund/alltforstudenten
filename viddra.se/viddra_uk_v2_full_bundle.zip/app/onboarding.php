<?php
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();

$page_title = "Setup — Viddra";
$uid = Auth::userId();
$hid = Household::currentId();
if ($hid <= 0) { $hid = Household::ensureDefaultForUser($uid); Household::setCurrentId($hid); }

$pdo = Database::pdo();
$stmt = $pdo->prepare("SELECT * FROM viddra_household_financials WHERE household_id=? LIMIT 1");
$stmt->execute([$hid]);
$fin = $stmt->fetch();
if (!$fin){
  $pdo->prepare("INSERT INTO viddra_household_financials (household_id, income_total, fixed_total, goal_total, created_at, updated_at) VALUES (?,0,0,0,NOW(),NOW())")->execute([$hid]);
  $stmt = $pdo->prepare("SELECT * FROM viddra_household_financials WHERE household_id=? LIMIT 1");
  $stmt->execute([$hid]);
  $fin = $stmt->fetch();
}

$step = (int)($_GET['step'] ?? 1);
$step = max(1, min(5, $step));
$err = null;

function go_step($s){ header("Location: /app/onboarding.php?step=".$s); exit; }

if ($_SERVER['REQUEST_METHOD']==='POST'){
  if (!viddra_csrf_check($_POST['csrf'] ?? '')) {
    $err = "Session expired. Please try again.";
  } else {
    if ($step === 1){
      $name = trim((string)($_POST['household_name'] ?? ''));
      if ($name === '') $name = "My household";
      Household::rename($GLOBALS['hid'], $name);
      go_step(2);
    } elseif ($step === 2){
      $income = (float)($_POST['income_total'] ?? 0);
      $pdo->prepare("UPDATE viddra_household_financials SET income_total=?, updated_at=NOW() WHERE household_id=?")->execute([$income, $hid]);
      go_step(3);
    } elseif ($step === 3){
      $fixed = (float)($_POST['fixed_total'] ?? 0);
      $pdo->prepare("UPDATE viddra_household_financials SET fixed_total=?, updated_at=NOW() WHERE household_id=?")->execute([$fixed, $hid]);
      go_step(4);
    } elseif ($step === 4){
      $goal = (float)($_POST['goal_total'] ?? 0);
      $pdo->prepare("UPDATE viddra_household_financials SET goal_total=?, updated_at=NOW() WHERE household_id=?")->execute([$goal, $hid]);
      go_step(5);
    } else {
      header("Location: /app/dashboard.php"); exit;
    }
  }
}

include __DIR__ . '/../includes/header.php';
?>
<section class="section">
  <div class="container">
    <span class="pill">Setup • Step <?php echo (int)$step; ?>/5</span>
    <h1>Build your monthly system.</h1>
    <p class="lead">This isn't banking. It's a calm structure: what's locked, what's left, and what's possible.</p>

    <?php if ($err): ?><p class="tiny warn"><?php echo htmlspecialchars($err, ENT_QUOTES,'UTF-8'); ?></p><?php endif; ?>

    <div class="card">
      <?php if ($step===1): ?>
        <h2>Name your household</h2>
        <form method="post">
          <input type="hidden" name="csrf" value="<?php echo htmlspecialchars(viddra_csrf_token(), ENT_QUOTES,'UTF-8'); ?>">
          <div class="field">
            <label>Household name</label>
            <input name="household_name" placeholder="e.g. Jim & Linnea" />
          </div>
          <div class="form-actions">
            <button class="btn primary" type="submit">Continue</button>
            <a class="btn" href="/app/dashboard.php">Skip for now</a>
          </div>
        </form>
      <?php elseif ($step===2): ?>
        <h2>Income</h2>
        <p class="lead">How much comes in per month (after tax)?</p>
        <form method="post">
          <input type="hidden" name="csrf" value="<?php echo htmlspecialchars(viddra_csrf_token(), ENT_QUOTES,'UTF-8'); ?>">
          <div class="field">
            <label>Total monthly income (£)</label>
            <input name="income_total" type="number" step="0.01" value="<?php echo htmlspecialchars((string)($fin['income_total'] ?? 0), ENT_QUOTES,'UTF-8'); ?>">
          </div>
          <div class="form-actions">
            <a class="btn" href="/app/onboarding.php?step=1">Back</a>
            <button class="btn primary" type="submit">Continue</button>
          </div>
        </form>
      <?php elseif ($step===3): ?>
        <h2>Fixed costs</h2>
        <p class="lead">Rent/mortgage, utilities, subscriptions, childcare — the essentials.</p>
        <form method="post">
          <input type="hidden" name="csrf" value="<?php echo htmlspecialchars(viddra_csrf_token(), ENT_QUOTES,'UTF-8'); ?>">
          <div class="field">
            <label>Fixed total (£/month)</label>
            <input name="fixed_total" type="number" step="0.01" value="<?php echo htmlspecialchars((string)($fin['fixed_total'] ?? 0), ENT_QUOTES,'UTF-8'); ?>">
          </div>
          <div class="form-actions">
            <a class="btn" href="/app/onboarding.php?step=2">Back</a>
            <button class="btn primary" type="submit">Continue</button>
          </div>
        </form>
      <?php elseif ($step===4): ?>
        <h2>Goals</h2>
        <p class="lead">Savings, debt payoff, holiday fund — money you want to protect.</p>
        <form method="post">
          <input type="hidden" name="csrf" value="<?php echo htmlspecialchars(viddra_csrf_token(), ENT_QUOTES,'UTF-8'); ?>">
          <div class="field">
            <label>Goals total (£/month)</label>
            <input name="goal_total" type="number" step="0.01" value="<?php echo htmlspecialchars((string)($fin['goal_total'] ?? 0), ENT_QUOTES,'UTF-8'); ?>">
          </div>
          <div class="form-actions">
            <a class="btn" href="/app/onboarding.php?step=3">Back</a>
            <button class="btn primary" type="submit">Continue</button>
          </div>
        </form>
      <?php else: ?>
        <h2>Snapshot</h2>
        <?php
          $income = (float)($fin['income_total'] ?? 0);
          $locked = abs((float)($fin['fixed_total'] ?? 0)) + abs((float)($fin['goal_total'] ?? 0));
          $left = $income - $locked;
        ?>
        <div class="grid three" style="margin-top:12px">
          <div class="kpi"><div class="label">Income</div><div class="value">£<?php echo number_format($income,0); ?></div></div>
          <div class="kpi"><div class="label">Locked</div><div class="value">£<?php echo number_format($locked,0); ?></div></div>
          <div class="kpi"><div class="label">Flexible</div><div class="value">£<?php echo number_format($left,0); ?></div></div>
        </div>
        <p class="lead" style="margin-top:12px">This is your month: bills + goals are protected, and the rest is yours to allocate.</p>
        <div class="form-actions" style="margin-top:8px">
          <a class="btn" href="/app/onboarding.php?step=4">Back</a>
          <a class="btn primary" href="/app/dashboard.php">Go to dashboard</a>
        </div>
      <?php endif; ?>
    </div>
  </div>
</section>
<?php include __DIR__ . '/../includes/footer.php'; ?>
