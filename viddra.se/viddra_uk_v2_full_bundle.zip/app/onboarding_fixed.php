<?php
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
Auth::requireVerifiedEmail();

$page_title = "Fixed costs — Onboarding — Viddra";

$hid = Household::currentId();
$fin = Financials::get($hid);

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST'){
  if (!viddra_csrf_check($_POST['csrf'] ?? '')) {
    $error = "Session expired. Please try again.";
  } else {
    $rent = preg_replace('/[^0-9.]/','', (string)($_POST['rent'] ?? ''));
    $utilities = preg_replace('/[^0-9.]/','', (string)($_POST['utilities'] ?? ''));
    $insurance = preg_replace('/[^0-9.]/','', (string)($_POST['insurance'] ?? ''));
    $subscriptions = preg_replace('/[^0-9.]/','', (string)($_POST['subscriptions'] ?? ''));

    $state['fixed_rent'] = $rent;
    $state['fixed_utilities'] = $utilities;
    $state['fixed_insurance'] = $insurance;
    $state['fixed_subscriptions'] = $subscriptions;
    Financials::updateFixed($hid, $rent, $utilities, $insurance, $subscriptions);

    header("Location: /app/onboarding_goals.php"); exit;
  }
}

include __DIR__ . '/../includes/header.php';
?>
<section class="section">
  <div class="container">
    <div class="card big onboarding-card">
      <div class="progress"><div class="progress-bar" style="width:60%"></div></div>
      <p class="tiny muted" style="margin-top:10px">Step 3 of 5</p>

      <h1>Fixed costs</h1>
      <p class="lead">Add the bills that happen every month.</p>

      <?php if ($error): ?><p class="tiny warn"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></p><?php endif; ?>

      <form method="post" action="/app/onboarding_fixed.php" class="sim-form" style="margin-top:14px" id="obFixedForm">
        <input type="hidden" name="csrf" value="<?php echo htmlspecialchars(viddra_csrf_token(), ENT_QUOTES, 'UTF-8'); ?>">

        <div class="grid3">
          <div class="ob-field">
            <label for="rent">Rent / Mortgage</label>
            <input id="rent" name="rent" inputmode="decimal" placeholder="e.g. 1150" value="<?php echo htmlspecialchars($fin['fixed_rent'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
            <div class="tiny muted ob-note">Housing cost.</div>
          </div>

          <div class="ob-field">
            <label for="utilities">Utilities</label>
            <input id="utilities" name="utilities" inputmode="decimal" placeholder="e.g. 190" value="<?php echo htmlspecialchars($fin['fixed_utilities'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
            <div class="tiny muted ob-note">Energy, internet, council tax, etc.</div>
          </div>

          <div class="ob-field">
            <label for="insurance">Insurance</label>
            <input id="insurance" name="insurance" inputmode="decimal" placeholder="e.g. 75" value="<?php echo htmlspecialchars($fin['fixed_insurance'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
            <div class="tiny muted ob-note">Home, car, pet, etc.</div>
          </div>

          <div class="ob-field">
            <label for="subscriptions">Subscriptions</label>
            <input id="subscriptions" name="subscriptions" inputmode="decimal" placeholder="e.g. 48" value="<?php echo htmlspecialchars($fin['fixed_subscriptions'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
            <div class="tiny muted ob-note">Streaming, gym, apps, etc.</div>
          </div>
        </div>

        <div class="kpi-inline" aria-live="polite">
          <div>
            <div class="tiny muted">Monthly fixed total</div>
            <strong id="fixedTotal">£0.00</strong>
          </div>
          <div class="muted">You’ll see how much is left after fixed costs in the final step.</div>
        </div>

        <div class="mini-help">
          <strong>Tip:</strong> round up. It’s better to be slightly conservative.
        </div>

        <div class="ob-actions">
          <button class="btn primary" type="submit">Save & continue</button>
          <a class="btn" href="/app/onboarding_income.php">Back</a>
        </div>
      </form>

    </div>
  </div>
</section>

<script>
(function(){
  const ids = ['rent','utilities','insurance','subscriptions'];
  const els = ids.map(id => document.getElementById(id));
  const total = document.getElementById('fixedTotal');

  function parseVal(x){
    if(!x) return 0;
    x = (''+x).replace(/[^0-9.]/g,'');
    const n = parseFloat(x);
    return isNaN(n) ? 0 : n;
  }
  function fmtGBP(n){
    try{
      return new Intl.NumberFormat('en-GB',{style:'currency',currency:'GBP'}).format(n);
    }catch(e){
      return '£' + (Math.round(n*100)/100).toFixed(2);
    }
  }
  function recalc(){
    let sum = 0;
    els.forEach(el => sum += parseVal(el.value));
    total.textContent = fmtGBP(sum);
    try{
      ids.forEach(id => localStorage.setItem('viddra_onb_fixed_'+id, document.getElementById(id).value || ''));
    }catch(e){}
  }

  els.forEach(el => el.addEventListener('input', recalc));

  try{
    ids.forEach(id => {
      const v = localStorage.getItem('viddra_onb_fixed_'+id);
      const el = document.getElementById(id);
      if(v && el && !el.value) el.value = v;
    });
  }catch(e){}

  recalc();
})();
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
