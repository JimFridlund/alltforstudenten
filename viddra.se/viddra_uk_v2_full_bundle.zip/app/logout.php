<?php
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::logout();
header("Location: /app/login.php"); exit;
