<?php
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();

$page_title = "Decisions — Viddra";
$uid = Auth::userId();
$hid = Household::currentId();
if ($hid <= 0) { $hid = Household::ensureDefaultForUser($uid); Household::setCurrentId($hid); }

$pdo = Database::pdo();
$ym = date('Y-m');
$monthStart = $ym . '-01';
$monthEnd = date('Y-m-t');

$stmt = $pdo->prepare("SELECT * FROM viddra_household_financials WHERE household_id=? LIMIT 1");
$stmt->execute([$hid]);
$fin = $stmt->fetch();

$income = $fin ? (float)($fin['income_total'] ?? 0) : 0.0;
$fixed  = $fin ? (float)($fin['fixed_total'] ?? 0)  : 0.0;
$goal   = $fin ? (float)($fin['goal_total'] ?? 0)   : 0.0;

$stmt = $pdo->prepare("SELECT COALESCE(SUM(amount),0) AS s FROM viddra_transactions WHERE household_id=? AND tx_date BETWEEN ? AND ?");
$stmt->execute([$hid, $monthStart, $monthEnd]);
$actual = (float)$stmt->fetch()['s'];
$spent = abs(min(0,$actual));
$locked = abs($fixed)+abs($goal);

$amount = 0.0;
$label = "";
$result = null;

if ($_SERVER['REQUEST_METHOD']==='POST'){
  $label = trim((string)($_POST['label'] ?? ''));
  $amount = (float)($_POST['amount'] ?? 0);
  $impact = abs($amount);
  $after = ($income - $locked - $spent - $impact);
  $result = $after;
}

include __DIR__ . '/../includes/header.php';
?>
<section class="section">
  <div class="container">
    <span class="pill">Decision impact</span>
    <h1>Try a decision.</h1>
    <p class="lead">See what one purchase does to the rest of your month — before you commit.</p>

    <div class="grid two">
      <div class="card">
        <h2>Current picture</h2>
        <div class="grid three" style="margin-top:12px">
          <div class="kpi"><div class="label">Income</div><div class="value">£<?php echo number_format($income,0); ?></div></div>
          <div class="kpi"><div class="label">Locked</div><div class="value">£<?php echo number_format($locked,0); ?></div></div>
          <div class="kpi"><div class="label">Spent</div><div class="value">£<?php echo number_format($spent,0); ?></div></div>
        </div>
        <p class="tiny" style="margin-top:10px">Available right now: <strong>£<?php echo number_format(max(0,$income-$locked-$spent),0); ?></strong></p>
      </div>

      <div class="card">
        <h2>Decision</h2>
        <form method="post" class="sim-form">
          <input type="hidden" name="csrf" value="<?php echo htmlspecialchars(viddra_csrf_token(), ENT_QUOTES,'UTF-8'); ?>">
          <div class="field">
            <label>What is it?</label>
            <input name="label" placeholder="e.g. Weekend trip" value="<?php echo htmlspecialchars($label, ENT_QUOTES,'UTF-8'); ?>">
          </div>
          <div class="field">
            <label>Cost (£)</label>
            <input name="amount" type="number" step="0.01" placeholder="400" value="<?php echo htmlspecialchars((string)$amount, ENT_QUOTES,'UTF-8'); ?>">
          </div>
          <div class="form-actions">
            <button class="btn primary" type="submit">Calculate</button>
            <a class="btn" href="/app/transactions.php">Log spending</a>
          </div>
        </form>

        <?php if ($result !== null): ?>
          <div class="card small" style="margin-top:12px;box-shadow:none">
            <div class="tiny">After <strong><?php echo htmlspecialchars($label ?: "this decision", ENT_QUOTES,'UTF-8'); ?></strong>, you'd have:</div>
            <div class="kpi" style="margin-top:8px">
              <div class="label">Remaining this month</div>
              <div class="value">£<?php echo number_format($result,0); ?></div>
            </div>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>
<?php include __DIR__ . '/../includes/footer.php'; ?>
