<?php
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
Auth::requireVerifiedEmail();

$page_title = "Goals — Onboarding — Viddra";

$hid = Household::currentId();
$fin = Financials::get($hid);

$error = null;

function _vnum($x){
  $x = preg_replace('/[^0-9.]/','', (string)$x);
  if ($x === '') return '';
  return $x;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST'){
  if (!viddra_csrf_check($_POST['csrf'] ?? '')) {
    $error = "Session expired. Please try again.";
  } else {
    $goal_key = trim((string)($_POST['goal_key'] ?? ''));
    $target = _vnum($_POST['goal_target'] ?? '');
    $monthly = _vnum($_POST['goal_monthly'] ?? '');

    if ($goal_key === '') $goal_key = 'emergency';

    $state['goal_key'] = $goal_key;
    $state['goal_target'] = $target;
    $state['goal_monthly'] = $monthly;
    Financials::updateGoal($hid, $goal_key, $target, $monthly);

    header("Location: /app/onboarding_done.php"); exit;
  }
}

include __DIR__ . '/../includes/header.php';
?>
<section class="section">
  <div class="container">
    <div class="card big onboarding-card">
      <div class="progress"><div class="progress-bar" style="width:80%"></div></div>
      <p class="tiny muted" style="margin-top:10px">Step 4 of 5</p>

      <h1>Goals</h1>
      <p class="lead">Start with one goal. Clarity beats perfection.</p>

      <?php if ($error): ?><p class="tiny warn"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></p><?php endif; ?>

      <form method="post" action="/app/onboarding_goals.php" class="sim-form" style="margin-top:14px" id="obGoalsForm">
        <input type="hidden" name="csrf" value="<?php echo htmlspecialchars(viddra_csrf_token(), ENT_QUOTES, 'UTF-8'); ?>">
        <input type="hidden" name="goal_key" id="goal_key" value="<?php echo htmlspecialchars($fin['goal_key'] ?? 'emergency', ENT_QUOTES, 'UTF-8'); ?>">

        <div class="goal-grid" id="goalGrid">
          <div class="goal-card" data-key="emergency">
            <div class="goal-top">
              <div class="goal-ico">🛟</div>
              <div>
                <p class="goal-title">Emergency fund</p>
                <p class="goal-sub">3–6 months of safety.</p>
              </div>
            </div>
          </div>

          <div class="goal-card" data-key="travel">
            <div class="goal-top">
              <div class="goal-ico">✈️</div>
              <div>
                <p class="goal-title">Travel</p>
                <p class="goal-sub">A trip you’ll remember.</p>
              </div>
            </div>
          </div>

          <div class="goal-card" data-key="home">
            <div class="goal-top">
              <div class="goal-ico">🏠</div>
              <div>
                <p class="goal-title">Home</p>
                <p class="goal-sub">Deposit, renovation, buffer.</p>
              </div>
            </div>
          </div>

          <div class="goal-card" data-key="freedom">
            <div class="goal-top">
              <div class="goal-ico">🕊️</div>
              <div>
                <p class="goal-title">Freedom</p>
                <p class="goal-sub">Build options over time.</p>
              </div>
            </div>
          </div>
        </div>

        <div class="goal-form">
          <div class="ob-field">
            <label for="goal_target">Goal target</label>
            <input id="goal_target" name="goal_target" inputmode="decimal" placeholder="e.g. 6000" value="<?php echo htmlspecialchars($fin['goal_target'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
            <div class="tiny muted ob-note">Total amount you want to reach.</div>
          </div>
          <div class="ob-field">
            <label for="goal_monthly">Monthly saving</label>
            <input id="goal_monthly" name="goal_monthly" inputmode="decimal" placeholder="e.g. 250" value="<?php echo htmlspecialchars($fin['goal_monthly'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
            <div class="tiny muted ob-note">A realistic monthly amount.</div>
          </div>

          <div class="kpi-inline">
            <div class="ring-wrap">
              <div class="ring" id="ring">
                <div class="ring-inner">
                  <strong id="months">—</strong>
                  <span>months</span>
                </div>
              </div>
              <div>
                <div class="tiny muted">Estimated completion</div>
                <strong id="eta">—</strong>
                <div class="tiny muted">You can adjust later.</div>
              </div>
            </div>
          </div>
        </div>

        <div class="ob-actions">
          <button class="btn primary" type="submit">Save & continue</button>
          <a class="btn" href="/app/onboarding_fixed.php">Back</a>
        </div>
      </form>

    </div>
  </div>
</section>

<script>
(function(){
  const grid = document.getElementById('goalGrid');
  const keyInput = document.getElementById('goal_key');
  const target = document.getElementById('goal_target');
  const monthly = document.getElementById('goal_monthly');
  const monthsEl = document.getElementById('months');
  const etaEl = document.getElementById('eta');
  const ring = document.getElementById('ring');

  function parseVal(x){
    if(!x) return 0;
    x = (''+x).replace(/[^0-9.]/g,'');
    const n = parseFloat(x);
    return isNaN(n) ? 0 : n;
  }

  function setSelected(key){
    keyInput.value = key;
    [...grid.querySelectorAll('.goal-card')].forEach(c=>{
      c.classList.toggle('selected', c.getAttribute('data-key')===key);
    });
    try{ localStorage.setItem('viddra_onb_goal_key', key); }catch(e){}
  }

  function addMonths(date, m){
    const d = new Date(date.getTime());
    const day = d.getDate();
    d.setMonth(d.getMonth()+m);
    if (d.getDate() < day) d.setDate(0);
    return d;
  }

  function fmtMonthYear(d){
    try{
      return d.toLocaleString('en-GB', { month: 'long', year: 'numeric' });
    }catch(e){
      return d.getFullYear() + '-' + (d.getMonth()+1);
    }
  }

  function recalc(){
    const t = parseVal(target.value);
    const m = parseVal(monthly.value);

    let months = 0;
    if (t > 0 && m > 0) months = Math.ceil(t / m);

    if (!months){
      monthsEl.textContent = '—';
      etaEl.textContent = '—';
      ring.style.background = 'conic-gradient(#3f5a3c 0deg, rgba(31,31,26,.12) 0deg)';
    } else {
      monthsEl.textContent = String(months);
      const eta = addMonths(new Date(), months);
      etaEl.textContent = fmtMonthYear(eta);

      // visual ring: cap at 24 months for display
      const capped = Math.min(months, 24);
      const pct = Math.max(5, Math.round((24 - capped) / 24 * 100)); // smaller months => bigger fill
      const deg = Math.round(pct * 3.6);
      ring.style.background = `conic-gradient(#3f5a3c ${deg}deg, rgba(31,31,26,.12) 0deg)`;
    }

    try{
      localStorage.setItem('viddra_onb_goal_target', target.value||'');
      localStorage.setItem('viddra_onb_goal_monthly', monthly.value||'');
    }catch(e){}
  }

  grid.addEventListener('click', (e)=>{
    const card = e.target.closest('.goal-card');
    if (!card) return;
    setSelected(card.getAttribute('data-key'));
  });

  [target, monthly].forEach(el => el.addEventListener('input', recalc));

  // restore
  try{
    const k = localStorage.getItem('viddra_onb_goal_key');
    if (k) setSelected(k);
    else setSelected(keyInput.value || 'emergency');

    const t = localStorage.getItem('viddra_onb_goal_target');
    const m = localStorage.getItem('viddra_onb_goal_monthly');
    if (t && !target.value) target.value = t;
    if (m && !monthly.value) monthly.value = m;
  }catch(e){
    setSelected(keyInput.value || 'emergency');
  }

  recalc();
})();
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
