<?php
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
Auth::requireVerifiedEmail();
Billing::requireActive();

$page_title = "Household — Viddra";
$uid = Auth::userId();
$hid = Household::currentId();
Invite::markExpired();

$error = null;
$success = null;
$invite_link = null;

if (isset($_GET['err']) && $_GET['err']==='not_member') $error = "You are not a member of that household.";
if (isset($_GET['err']) && $_GET['err']==='csrf') $error = "Session expired. Please try again.";
if (isset($_GET['ok']) && $_GET['ok']==='switch') $success = "Household switched.";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['action'] ?? '';
  if (!viddra_csrf_check($_POST['csrf'] ?? '')) {
    $error = "Session expired. Please try again.";
  } else if ($action === 'invite') {
    $email = $_POST['email'] ?? '';
    [$ok, $msg, $token] = Invite::create($hid, $uid, $email, true);
    if ($ok) {
      $success = "Invite created and email sent (if mail() is configured).";
      $invite_link = "/app/accept_invite.php?t=" . urlencode($token); // fallback
    } else {
      $error = $msg;
    }
  } else if ($action === 'rename') {
    $name = $_POST['household_name'] ?? '';
    [$ok, $msg] = Household::rename($hid, $name);
    if ($ok) $success = "Household renamed.";
    else $error = $msg;
  } else if ($action === 'cancel_invite') {
    $id = (int)($_POST['invite_id'] ?? 0);
    Invite::cancel($id, $hid);
    $success = "Invite cancelled.";
  } else if ($action === 'resend_invite') {
    $id = (int)($_POST['invite_id'] ?? 0);
    [$ok, $msg, $token] = Invite::resend($id, $hid);
    if ($ok) {
      $success = "Invite re-sent (new token created).";
      $invite_link = "/app/accept_invite.php?t=" . urlencode($token); // fallback
    } else {
      $error = $msg;
    }
  }
}

$households = Household::userHouseholds($uid);
$members = Household::members($hid);
$invites = Invite::listForHousehold($hid);

include __DIR__ . '/../includes/header.php';
?>
<section class="section">
  <div class="container">
    <div class="page-top">
      <div>
        <h1>Household</h1>
        <p class="lead">Switch household, invite members, and manage shared scenarios.</p>
      </div>
      <div class="kpi-chip">
        <div class="kpi-chip-label">Current</div>
        <div class="kpi-chip-value">#<?php echo (int)$hid; ?></div>
      </div>
    </div>

    <?php if ($error): ?>
      <p class="tiny warn"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></p>
    <?php endif; ?>
    <?php if ($success): ?>
      <p class="tiny" style="font-weight:900;color:rgba(63,90,60,.95)"><?php echo htmlspecialchars($success, ENT_QUOTES, 'UTF-8'); ?></p>
    <?php endif; ?>

    <?php if ($invite_link): ?>
      <div class="mini-callout" style="margin:10px 0 18px 0">
        <strong>Fallback link (manual):</strong><br>
        <code><?php echo htmlspecialchars($invite_link, ENT_QUOTES, 'UTF-8'); ?></code>
        <div class="tiny muted" style="margin-top:6px">Use this if email sending isn’t configured yet.</div>
      </div>
    <?php endif; ?>

    <div class="cards two">
      <div class="card big">
        <h2>Switch household</h2>
        <p class="muted">If you belong to multiple households, pick the active one.</p>

        <form class="sim-form" method="post" action="/app/switch_household.php">
          <input type="hidden" name="csrf" value="<?php echo htmlspecialchars(viddra_csrf_token(), ENT_QUOTES, 'UTF-8'); ?>">
          <div class="field">
            <label for="household_id">Your households</label>
            <select id="household_id" name="household_id">
              <?php foreach ($households as $h): ?>
                <option value="<?php echo (int)$h['id']; ?>" <?php echo ((int)$h['id']===(int)$hid)?'selected':''; ?>>
                  #<?php echo (int)$h['id']; ?> — <?php echo htmlspecialchars($h['name'], ENT_QUOTES, 'UTF-8'); ?> (<?php echo htmlspecialchars($h['role'], ENT_QUOTES, 'UTF-8'); ?>)
                </option>
              <?php endforeach; ?>
            </select>
            <div class="hint">Forecast + Decisions are shared within the active household.</div>
          </div>
          <div class="form-actions">
            <button class="btn primary" type="submit">Switch</button>
          </div>
        </form>

        <div class="spacer"></div>

        <h3 style="margin-top:10px">Rename household</h3>
        <form class="sim-form" method="post" action="/app/household.php">
          <input type="hidden" name="csrf" value="<?php echo htmlspecialchars(viddra_csrf_token(), ENT_QUOTES, 'UTF-8'); ?>">
          <input type="hidden" name="action" value="rename">
          <div class="field">
            <label for="household_name">Name</label>
            <input id="household_name" name="household_name" type="text" placeholder="e.g. Jim & Sverker" />
          </div>
          <div class="form-actions">
            <button class="btn" type="submit">Save name</button>
          </div>
        </form>
      </div>

      <div class="card big">
        <h2>Members</h2>
        <div class="signal">
          <?php foreach ($members as $m): ?>
            <div class="signal-row">
              <span>
                <?php echo htmlspecialchars($m['email'] ?? ('User #' . $m['id']), ENT_QUOTES, 'UTF-8'); ?><br>
                <span class="tiny muted"><?php echo htmlspecialchars($m['created_at'], ENT_QUOTES, 'UTF-8'); ?></span>
              </span>
              <strong><?php echo htmlspecialchars($m['role'], ENT_QUOTES, 'UTF-8'); ?></strong>
            </div>
          <?php endforeach; ?>
        </div>

        <div class="mini-callout">
          <strong>Sharing:</strong> everyone in this household sees the same Decisions + Forecast.
        </div>
      </div>
    </div>

    <div class="cards two">
      <div class="card big">
        <h2>Create invite</h2>

        <form class="sim-form" method="post" action="/app/household.php">
          <input type="hidden" name="csrf" value="<?php echo htmlspecialchars(viddra_csrf_token(), ENT_QUOTES, 'UTF-8'); ?>">
          <input type="hidden" name="action" value="invite">
          <div class="field">
            <label for="email">Invite by email</label>
            <input id="email" name="email" type="email" required placeholder="partner@example.com" />
            <div class="hint">We send an email automatically (uses PHP mail()).</div>
          </div>
          <div class="form-actions">
            <button class="btn primary" type="submit">Send invite</button>
          </div>
        </form>
      </div>

      <div class="card big">
        <h2>Invites</h2>
        <div class="signal">
          <?php if (!$invites): ?>
            <p class="muted">No invites yet.</p>
          <?php else: ?>
            <?php foreach ($invites as $inv): ?>
              <div class="signal-row">
                <span><?php echo htmlspecialchars($inv['email'], ENT_QUOTES, 'UTF-8'); ?><br><span class="tiny muted"><?php echo htmlspecialchars($inv['created_at'], ENT_QUOTES, 'UTF-8'); ?></span></span>
                <strong><?php echo htmlspecialchars($inv['status'], ENT_QUOTES, 'UTF-8'); ?></strong>
              </div>
              <?php if ($inv['status'] === 'pending'): ?>
                <form method="post" action="/app/household.php" style="display:flex;gap:10px;margin:8px 0 14px 0">
                  <input type="hidden" name="csrf" value="<?php echo htmlspecialchars(viddra_csrf_token(), ENT_QUOTES, 'UTF-8'); ?>">
                  <input type="hidden" name="invite_id" value="<?php echo (int)$inv['id']; ?>">
                  <button class="btn" type="submit" name="action" value="resend_invite">Resend</button>
                  <button class="btn" type="submit" name="action" value="cancel_invite">Cancel</button>
                </form>
              <?php endif; ?>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>

        <div class="mini-callout">
          <strong>Note:</strong> resending creates a new token (we store only hashes).
        </div>
      </div>
    </div>

  </div>
</section>
<?php include __DIR__ . '/../includes/footer.php'; ?>
