<?php
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
Auth::requireVerifiedEmail();

$page_title = "Income — Onboarding — Viddra";

$hid = Household::currentId();
$fin = Financials::get($hid);

$success = null;
$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST'){
  if (!viddra_csrf_check($_POST['csrf'] ?? '')) {
    $error = "Session expired. Please try again.";
  } else {
    $a = trim((string)($_POST['income_a'] ?? ''));
    $b = trim((string)($_POST['income_b'] ?? ''));
    $a = preg_replace('/[^0-9.]/', '', $a);
    $b = preg_replace('/[^0-9.]/', '', $b);

    $state['income_a'] = $a;
    $state['income_b'] = $b;
    Financials::updateIncome($hid, $a, $b);

    header("Location: /app/onboarding_fixed.php"); exit;
  }
}

include __DIR__ . '/../includes/header.php';
?>
<section class="section">
  <div class="container">
    <div class="card big onboarding-card">
      <div class="progress"><div class="progress-bar" style="width:40%"></div></div>
      <p class="tiny muted" style="margin-top:10px">Step 2 of 5</p>

      <h1>Income</h1>
      <p class="lead">Add monthly income after tax. You can change this anytime.</p>

      <?php if ($error): ?><p class="tiny warn"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></p><?php endif; ?>

      <form method="post" action="/app/onboarding_income.php" class="sim-form" style="margin-top:14px" id="obIncomeForm">
        <input type="hidden" name="csrf" value="<?php echo htmlspecialchars(viddra_csrf_token(), ENT_QUOTES, 'UTF-8'); ?>">

        <div class="ob-row">
          <div class="ob-field">
            <label for="income_a">Primary income</label>
            <input id="income_a" name="income_a" inputmode="decimal" placeholder="e.g. 2800" value="<?php echo htmlspecialchars($fin['income_a'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
            <div class="tiny muted ob-note">Your main monthly pay.</div>
          </div>

          <div class="ob-field" id="secondaryWrap" style="display:none">
            <label for="income_b">Second income (optional)</label>
            <input id="income_b" name="income_b" inputmode="decimal" placeholder="e.g. 1200" value="<?php echo htmlspecialchars($fin['income_b'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
            <div class="tiny muted ob-note">Partner, side income, etc.</div>
          </div>
        </div>

        <div style="margin-top:10px">
          <button type="button" class="btn ghost" id="toggleSecondary">Add second income</button>
        </div>

        <div class="kpi-inline" aria-live="polite">
          <div>
            <div class="tiny muted">Monthly total income</div>
            <strong id="incomeTotal">£0.00</strong>
          </div>
          <div class="muted">Used to calculate your real monthly position.</div>
        </div>

        <div class="ob-actions">
          <button class="btn primary" type="submit">Save & continue</button>
          <a class="btn" href="/app/onboarding.php">Back</a>
        </div>
      </form>

    </div>
  </div>
</section>

<script>
(function(){
  const a = document.getElementById('income_a');
  const b = document.getElementById('income_b');
  const wrap = document.getElementById('secondaryWrap');
  const btn = document.getElementById('toggleSecondary');
  const total = document.getElementById('incomeTotal');

  function parseVal(x){
    if(!x) return 0;
    x = (''+x).replace(/[^0-9.]/g,'');
    const n = parseFloat(x);
    return isNaN(n) ? 0 : n;
  }
  function fmtGBP(n){
    try{
      return new Intl.NumberFormat('en-GB',{style:'currency',currency:'GBP'}).format(n);
    }catch(e){
      return '£' + (Math.round(n*100)/100).toFixed(2);
    }
  }
  function recalc(){
    const sum = parseVal(a.value) + parseVal(b ? b.value : 0);
    total.textContent = fmtGBP(sum);
    try{
      localStorage.setItem('viddra_onb_income_a', a.value || '');
      localStorage.setItem('viddra_onb_income_b', b ? (b.value||'') : '');
      localStorage.setItem('viddra_onb_income_has_b', wrap.style.display==='block' ? '1' : '0');
    }catch(e){}
  }

  btn.addEventListener('click', function(){
    const shown = wrap.style.display === 'block';
    wrap.style.display = shown ? 'none' : 'block';
    btn.textContent = shown ? 'Add second income' : 'Hide second income';
    recalc();
  });

  [a,b].forEach(el => el && el.addEventListener('input', recalc));

  try{
    const hasB = localStorage.getItem('viddra_onb_income_has_b');
    const va = localStorage.getItem('viddra_onb_income_a');
    const vb = localStorage.getItem('viddra_onb_income_b');
    if(va && !a.value) a.value = va;
    if(vb && b && !b.value) b.value = vb;
    if(hasB === '1'){
      wrap.style.display = 'block';
      btn.textContent = 'Hide second income';
    }
  }catch(e){}

  recalc();
})();
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
