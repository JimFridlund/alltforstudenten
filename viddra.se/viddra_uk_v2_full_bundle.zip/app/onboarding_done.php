<?php
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
Auth::requireVerifiedEmail();

$page_title = "You’re live — Onboarding — Viddra";

$hid = Household::currentId();
$fin = Financials::get($hid);
$snap = Financials::snapshot($hid);

function _gbp($n){
  return "£" . number_format((float)$n, 2, '.', ',');
}

$income = $snap ? $snap['income'] : 0;
$fixed = $snap ? $snap['fixed'] : 0;
$available = $snap ? $snap['available'] : 0;
$goal_monthly = $snap ? $snap['goal_monthly'] : 0;
$free = $snap ? $snap['free'] : 0;

$goal_key = $fin ? (string)$fin['goal_key'] : 'emergency';
$goal_title = [
  'emergency' => 'Emergency fund',
  'travel' => 'Travel',
  'home' => 'Home',
  'freedom' => 'Freedom'
][$goal_key] ?? 'Goal';

include __DIR__ . '/../includes/header.php';
?>
<section class="section">
  <div class="container">
    <div class="card big onboarding-card">
      <div class="progress"><div class="progress-bar" style="width:100%"></div></div>
      <p class="tiny muted" style="margin-top:10px">Step 5 of 5</p>

      <h1>You’re live</h1>
      <p class="lead">Here’s your first snapshot. You can refine it anytime.</p>

      <div class="snap-grid">
        <div class="snap-card">
          <h3>Monthly income</h3>
          <strong><?php echo _gbp($income); ?></strong>
        </div>
        <div class="snap-card">
          <h3>Fixed costs</h3>
          <strong><?php echo _gbp($fixed); ?></strong>
        </div>
        <div class="snap-card">
          <h3>Available</h3>
          <strong><?php echo _gbp($available); ?></strong>
        </div>
      </div>

      <div class="snap-big">
        <div class="snap-row"><span>Available after fixed</span><strong><?php echo _gbp($available); ?></strong></div>
        <div class="snap-row"><span>Monthly saving toward <?php echo htmlspecialchars($goal_title, ENT_QUOTES, 'UTF-8'); ?></span><strong><?php echo _gbp($goal_monthly); ?></strong></div>
        <hr style="border:none;border-top:1px solid rgba(31,31,26,.12);margin:10px 0">
        <div class="snap-row"><span><strong>Real free cash</strong></span><strong><?php echo _gbp($free); ?></strong></div>
        <p class="tiny muted" style="margin-top:10px">Real free cash is what you can spend without breaking the plan.</p>
      </div>

      <div class="form-actions" style="margin-top:18px">
        <a class="btn primary" href="/app/dashboard.php">Go to dashboard</a>
        <a class="btn" href="/app/onboarding_goals.php">Back</a>
      </div>

    </div>
  </div>
</section>
<?php include __DIR__ . '/../includes/footer.php'; ?>
