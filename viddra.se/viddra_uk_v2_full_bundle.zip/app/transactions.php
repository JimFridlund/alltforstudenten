<?php
require_once __DIR__ . '/../includes/bootstrap.php';
Auth::requireLogin();
Auth::requireVerifiedEmail();

$hid = Household::currentId();
$uid = Auth::userId();

Category::seedDefaults($hid);
$cats = Category::all($hid);

$error = null;

if ($_SERVER['REQUEST_METHOD']==='POST'){
  if (!viddra_csrf_check($_POST['csrf'] ?? '')) {
    $error = "Session expired. Please try again.";
  } else {
    if (isset($_POST['create_tx'])){
      $date = $_POST['tx_date'] ?? date('Y-m-d');
      $cat = $_POST['category_id'] ?? null;
      $amt = $_POST['amount'] ?? '0';
      $note = trim((string)($_POST['note'] ?? ''));
      Transaction::create($hid, $cat, $date, $amt, $note, $uid);
      header("Location: /app/transactions.php"); exit;
    }
    if (isset($_POST['delete_tx'])){
      Transaction::delete($hid, $_POST['delete_tx']);
      header("Location: /app/transactions.php"); exit;
    }
  }
}

$txs = Transaction::listRecent($hid, 80);

$page_title = "Transactions — Viddra";
include __DIR__ . '/../includes/header.php';
?>

<section class="section">
<div class="container">
<div class="card big">

<h1>Transactions</h1>
<p class="muted">Manual entry for now. Fast, clean, and household-based.</p>

<?php if ($error): ?><p class="tiny warn"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></p><?php endif; ?>

<form method="post" class="sim-form" style="margin-top:14px">
  <input type="hidden" name="csrf" value="<?php echo htmlspecialchars(viddra_csrf_token(), ENT_QUOTES, 'UTF-8'); ?>">
  <div class="ob-row">
    <div class="ob-field">
      <label>Date</label>
      <input type="date" name="tx_date" value="<?php echo date('Y-m-d'); ?>">
      <div class="tiny muted ob-note">When it happened.</div>
    </div>
    <div class="ob-field">
      <label>Category</label>
      <select name="category_id" style="width:100%;padding:12px 14px;border-radius:14px;border:1px solid rgba(31,31,26,.16);background:rgba(255,255,255,.7)">
        <option value="">— None —</option>
        <?php foreach ($cats as $c): ?>
          <option value="<?php echo (int)$c['id']; ?>"><?php echo htmlspecialchars($c['name'], ENT_QUOTES, 'UTF-8'); ?> (<?php echo htmlspecialchars($c['type'], ENT_QUOTES, 'UTF-8'); ?>)</option>
        <?php endforeach; ?>
      </select>
      <div class="tiny muted ob-note">Where it belongs.</div>
    </div>
    <div class="ob-field">
      <label>Amount (GBP)</label>
      <input type="text" name="amount" inputmode="decimal" placeholder="e.g. -42.50">
      <div class="tiny muted ob-note">Use negative for spending, positive for refunds.</div>
    </div>
  </div>

  <div class="ob-field" style="margin-top:12px">
    <label>Note (optional)</label>
    <input type="text" name="note" placeholder="e.g. Tesco weekly shop">
  </div>

  <div class="ob-actions" style="margin-top:14px">
    <button class="btn primary" name="create_tx" value="1">Add transaction</button>
    <a class="btn" href="/app/categories.php">Manage categories</a>
  </div>
</form>

<hr style="margin:18px 0">

<h2 style="margin-top:0">Recent</h2>
<table style="width:100%;margin-top:10px">
  <tr>
    <th align="left">Date</th>
    <th align="left">Category</th>
    <th align="right">Amount</th>
    <th align="left">Note</th>
    <th></th>
  </tr>
  <?php foreach ($txs as $t): ?>
  <tr>
    <td><?php echo htmlspecialchars($t['tx_date'], ENT_QUOTES, 'UTF-8'); ?></td>
    <td><?php echo htmlspecialchars($t['category_name'] ?? '—', ENT_QUOTES, 'UTF-8'); ?></td>
    <td align="right" style="font-weight:900"><?php echo "£" . number_format((float)$t['amount'], 2, '.', ','); ?></td>
    <td><?php echo htmlspecialchars($t['note'] ?? '', ENT_QUOTES, 'UTF-8'); ?></td>
    <td align="right">
      <form method="post" style="display:inline">
        <input type="hidden" name="csrf" value="<?php echo htmlspecialchars(viddra_csrf_token(), ENT_QUOTES, 'UTF-8'); ?>">
        <button class="btn" name="delete_tx" value="<?php echo (int)$t['id']; ?>">Delete</button>
      </form>
    </td>
  </tr>
  <?php endforeach; ?>
</table>

</div>
</div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
