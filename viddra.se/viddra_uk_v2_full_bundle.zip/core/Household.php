<?php
/**
 * Household (v2)
 * - ensures each user has a default household
 * - stores current household id in session
 * - list households for user
 * - list members for household
 */
class Household {

  public static function currentId(){
    if (isset($_SESSION['viddra_household_id']) && (int)$_SESSION['viddra_household_id'] > 0) {
      return (int)$_SESSION['viddra_household_id'];
    }
    return 0;
  }

  public static function setCurrentId($hid){
    $_SESSION['viddra_household_id'] = (int)$hid;
  }

  public static function ensureDefaultForUser($userId){
    $userId = (int)$userId;
    if ($userId <= 0) return 0;

    $pdo = Database::pdo();

    $stmt = $pdo->prepare("SELECT household_id FROM viddra_user_households WHERE user_id = ? ORDER BY created_at ASC LIMIT 1");
    $stmt->execute([$userId]);
    $row = $stmt->fetch();
    if ($row && isset($row['household_id'])) {
      return (int)$row['household_id'];
    }

    $pdo->beginTransaction();
    try {
      $stmt = $pdo->prepare("INSERT INTO viddra_households (name, created_at) VALUES (?, NOW())");
      $stmt->execute(["My household"]);
      $hid = (int)$pdo->lastInsertId();

      $stmt = $pdo->prepare("INSERT INTO viddra_user_households (user_id, household_id, role, created_at) VALUES (?, ?, 'owner', NOW())");
      $stmt->execute([$userId, $hid]);

      $pdo->commit();
      return $hid;
    } catch (Exception $e){
      $pdo->rollBack();
      throw $e;
    }
  }

  public static function userHouseholds($userId){
    $pdo = Database::pdo();
    $stmt = $pdo->prepare("
      SELECT h.id, h.name, uh.role, uh.created_at
      FROM viddra_user_households uh
      JOIN viddra_households h ON h.id = uh.household_id
      WHERE uh.user_id = ?
      ORDER BY uh.created_at ASC
    ");
    $stmt->execute([(int)$userId]);
    return $stmt->fetchAll();
  }

  public static function userBelongsTo($userId, $householdId){
    $pdo = Database::pdo();
    $stmt = $pdo->prepare("SELECT 1 FROM viddra_user_households WHERE user_id=? AND household_id=? LIMIT 1");
    $stmt->execute([(int)$userId, (int)$householdId]);
    return (bool)$stmt->fetch();
  }

  public static function members($householdId){
    $pdo = Database::pdo();
    $stmt = $pdo->prepare("
      SELECT u.id, u.email, uh.role, uh.created_at
      FROM viddra_user_households uh
      JOIN viddra_users u ON u.id = uh.user_id
      WHERE uh.household_id = ?
      ORDER BY uh.created_at ASC
    ");
    $stmt->execute([(int)$householdId]);
    return $stmt->fetchAll();
  }

  public static function rename($householdId, $name){
    $name = trim((string)$name);
    if ($name === '') return [false, "Name cannot be empty."];
    if (mb_strlen($name) > 120) return [false, "Name too long."];

    $pdo = Database::pdo();
    $stmt = $pdo->prepare("UPDATE viddra_households SET name=? WHERE id=?");
    $stmt->execute([$name, (int)$householdId]);
    return [true, null];
  }

  public static function ensureOwnerMember($householdId){
    $pdo = Database::pdo();
    // Find owner
    $stmt = $pdo->prepare("SELECT owner_user_id FROM viddra_households WHERE id=? LIMIT 1");
    $stmt->execute([(int)$householdId]);
    $row = $stmt->fetch();
    if (!$row) return;
    $ownerId = (int)$row['owner_user_id'];
    if ($ownerId <= 0) return;

    $stmt = $pdo->prepare("INSERT IGNORE INTO viddra_household_members (household_id, user_id, role, created_at) VALUES (?, ?, 'owner', NOW())");
    $stmt->execute([(int)$householdId, $ownerId]);
  }

  public static function addMember($householdId, $userId){
    $pdo = Database::pdo();
    self::ensureOwnerMember($householdId);
    $stmt = $pdo->prepare("INSERT IGNORE INTO viddra_household_members (household_id, user_id, role, created_at) VALUES (?, ?, 'member', NOW())");
    $stmt->execute([(int)$householdId, (int)$userId]);
  }

  public static function members($householdId){
    $pdo = Database::pdo();
    self::ensureOwnerMember($householdId);
    $stmt = $pdo->prepare("
      SELECT m.role, u.id AS user_id, u.email, u.email_verified_at, m.created_at
      FROM viddra_household_members m
      JOIN viddra_users u ON u.id = m.user_id
      WHERE m.household_id=?
      ORDER BY (m.role='owner') DESC, m.created_at ASC
    ");
    $stmt->execute([(int)$householdId]);
    return $stmt->fetchAll();
  }

}
?>
