<?php
/**
 * Auth (minimal, v1)
 * - register/login/logout
 * - session-based
 */
class Auth {
  public static function isLoggedIn(){
    return isset($_SESSION['viddra_user_id']) && (int)$_SESSION['viddra_user_id'] > 0;
  }

  public static function userId(){
    return self::isLoggedIn() ? (int)$_SESSION['viddra_user_id'] : 0;
  }

  public static function user(){
    if (!self::isLoggedIn()) return null;
    $pdo = Database::pdo();
    $stmt = $pdo->prepare("SELECT id,email,email_verified_at,created_at FROM viddra_users WHERE id = ? LIMIT 1");
    $stmt->execute([self::userId()]);
    return $stmt->fetch();
  }

  public static function login($email, $password){
    $email = self::normalizeEmail($email);
    if ($email === '' || $password === '') return [false, "Missing credentials."];

    $pdo = Database::pdo();
    $stmt = $pdo->prepare("SELECT id,email,email_verified_at,password_hash FROM viddra_users WHERE email = ? LIMIT 1");
    $stmt->execute([$email]);
    $u = $stmt->fetch();
    if (!$u || !$u['password_hash'] || !password_verify($password, $u['password_hash'])) {
      return [false, "Invalid email or password."];
    }

    session_regenerate_id(true);
    $_SESSION['viddra_user_id'] = (int)$u['id'];
    // Ensure household + set current
    $hid = Household::ensureDefaultForUser((int)$u['id']);
    Household::setCurrentId($hid);
    // Send verification email (best-effort)
    if (class_exists('EmailVerification')) { EmailVerification::sendToUser($id); }
    return [true, null];
  }

  public static function logout(){
    unset($_SESSION['viddra_user_id']);
    unset($_SESSION['viddra_household_id']);
    session_regenerate_id(true);
  }

  public static function register($email, $password){
    $email = self::normalizeEmail($email);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) return [false, "Please enter a valid email."];
    if (strlen($password) < 10) return [false, "Password must be at least 10 characters."];

    $hash = password_hash($password, PASSWORD_DEFAULT);
    $pdo = Database::pdo();

    // unique email
    $stmt = $pdo->prepare("SELECT id FROM viddra_users WHERE email = ? LIMIT 1");
    $stmt->execute([$email]);
    if ($stmt->fetch()) return [false, "That email is already registered."];

    $stmt = $pdo->prepare("INSERT INTO viddra_users (email, password_hash, created_at) VALUES (?, ?, NOW())");
    $stmt->execute([$email, $hash]);
    $id = (int)$pdo->lastInsertId();

    session_regenerate_id(true);
    $_SESSION['viddra_user_id'] = $id;
    // Create default household and set current
    $hid = Household::ensureDefaultForUser($id);
    Household::setCurrentId($hid);
    // Send verification email (best-effort)
    if (class_exists('EmailVerification')) { EmailVerification::sendToUser($id); }
    return [true, null];
  }

  
  public static function requireVerifiedEmail(){
    if (!defined('VIDDRA_REQUIRE_EMAIL_VERIFICATION') || VIDDRA_REQUIRE_EMAIL_VERIFICATION !== true) return;
    $u = self::user();
    if (!$u) return;
    if (!isset($u['email_verified_at']) || !$u['email_verified_at']) {
      header("Location: /app/verify_email.php"); exit;
    }
  }

  public static function requireLogin(){
    if (!self::isLoggedIn()){
      header("Location: /app/login.php"); exit;
    }
  }

  private static function normalizeEmail($email){
    $email = trim((string)$email);
    $email = strtolower($email);
    return $email;
  }
}
?>
