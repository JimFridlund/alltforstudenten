<?php
class Invite {

  public static function create($householdId, $email, $createdByUserId){
    $email = strtolower(trim((string)$email));
    if ($email === '') return [false, "Email is required."];

    $ttl = defined('VIDDRA_INVITE_TTL_HOURS') ? (int)VIDDRA_INVITE_TTL_HOURS : 168;
    $ttl = max(1, min(720, $ttl)); // 1h..30d

    $token = bin2hex(random_bytes(20));
    $hash = hash('sha256', $token);

    $pdo = Database::pdo();

    $stmt = $pdo->prepare("
      INSERT INTO viddra_household_invites
      (household_id, email, token_hash, last_token_plain, status, created_by_user_id, created_at, expires_at)
      VALUES (?, ?, ?, ?, 'pending', ?, NOW(), DATE_ADD(NOW(), INTERVAL {$ttl} HOUR))
    ");
    $lastToken = (defined('VIDDRA_SHOW_INVITE_COPY_LINK') && VIDDRA_SHOW_INVITE_COPY_LINK===true) ? $token : null;
    $stmt->execute([(int)$householdId, $email, $hash, $lastToken, (int)$createdByUserId]);

    self::sendEmail($email, $token);

    return [true, null, $token];
  }

  public static function sendEmail($email, $token){
    $base = defined('VIDDRA_BASE_URL') ? rtrim(VIDDRA_BASE_URL, '/') : '';
    $link = $base . "/app/accept_invite.php?t=" . urlencode($token);

    $subject = "You’ve been invited to join a Viddra household";
    $html = "
      <div style='font-family:Arial,Helvetica,sans-serif;line-height:1.5'>
        <h2 style='margin:0 0 8px 0'>You’re invited</h2>
        <p>Click below to accept the invite.</p>
        <p style='margin:16px 0'>
          <a href='{$link}' style='display:inline-block;padding:10px 14px;border-radius:10px;background:#3f5a3c;color:#fff;text-decoration:none;font-weight:bold'>
            Accept invite
          </a>
        </p>
        <p style='color:#666;font-size:13px'>If the button doesn’t work, copy this link:</p>
        <p style='font-size:13px;word-break:break-all'>{$link}</p>
      </div>
    ";

    Mailer::send($email, $subject, $html);
  }

  public static function listByHousehold($householdId){
    $pdo = Database::pdo();
    $stmt = $pdo->prepare("
      SELECT *
      FROM viddra_household_invites
      WHERE household_id=?
      ORDER BY created_at DESC
      LIMIT 200
    ");
    $stmt->execute([(int)$householdId]);
    return $stmt->fetchAll();
  }

  public static function revoke($inviteId, $userId){
    $pdo = Database::pdo();
    $stmt = $pdo->prepare("
      UPDATE viddra_household_invites
      SET status='revoked', revoked_at=NOW(), revoked_by_user_id=?, updated_at=NOW()
      WHERE id=? AND status='pending'
    ");
    $stmt->execute([(int)$userId, (int)$inviteId]);
  }

  public static function markExpired(){
    // No cron required: call in-page occasionally
    $pdo = Database::pdo();
    $pdo->exec("UPDATE viddra_household_invites SET status='expired', updated_at=NOW() WHERE status='pending' AND expires_at IS NOT NULL AND expires_at < NOW()");
  }

  public static function resend($inviteId, $userId){
    $pdo = Database::pdo();
    self::markExpired();

    // We cannot resend without the original token. So we generate a new token and replace token_hash.
    $token = bin2hex(random_bytes(20));
    $hash = hash('sha256', $token);

    $ttl = defined('VIDDRA_INVITE_TTL_HOURS') ? (int)VIDDRA_INVITE_TTL_HOURS : 168;
    $ttl = max(1, min(720, $ttl));

    $stmt = $pdo->prepare("SELECT email,status FROM viddra_household_invites WHERE id=? LIMIT 1");
    $stmt->execute([(int)$inviteId]);
    $row = $stmt->fetch();
    if (!$row) return [false, "Invite not found."];
    if ($row['status'] !== 'pending') return [false, "Only pending invites can be resent."];

    $stmt = $pdo->prepare("
      UPDATE viddra_household_invites
      SET token_hash=?, last_token_plain=?, resent_at=NOW(), resent_count=resent_count+1, expires_at=DATE_ADD(NOW(), INTERVAL {$ttl} HOUR), updated_at=NOW()
      WHERE id=?
    ");
    $lastToken = (defined('VIDDRA_SHOW_INVITE_COPY_LINK') && VIDDRA_SHOW_INVITE_COPY_LINK===true) ? $token : null;
    $stmt->execute([$hash, $lastToken, (int)$inviteId]);

    self::sendEmail($row['email'], $token);
    return [true, null];
  }
}
?>
